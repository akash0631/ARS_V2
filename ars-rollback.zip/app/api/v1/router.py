"""
API v1 Router - Aggregates all endpoint routers
"""
from fastapi import APIRouter

# Phase 1: Auth, RBAC, RLS, Audit
from app.api.v1.endpoints.auth import router as auth_router
from app.api.v1.endpoints.users import router as users_router
from app.api.v1.endpoints.roles import router as roles_router
from app.api.v1.endpoints.rls import router as rls_router
from app.api.v1.endpoints.audit import router as audit_router

# Phase 2: Table Management, Upsert, Upload
from app.api.v1.endpoints.tables import router as tables_router
from app.api.v1.endpoints.data_ops import router as data_ops_router
from app.api.v1.endpoints.upload import router as upload_router

# Phase 3: Allocation Engine
from app.api.v1.endpoints.allocations import router as allocations_router

# Phase 4: MSA Stock Calculation
from app.api.v1.endpoints.msa_stock import router as msa_router
from app.api.v1.endpoints.msa import router as msa_legacy_router

# Phase 4b: Contribution Percentage
from app.api.v1.endpoints.contrib import router as contrib_router

# Phase 4c: BDC Creation
from app.api.v1.endpoints.bdc import router as bdc_router

# Phase 5: Settings
from app.api.v1.endpoints.settings import router as settings_router

# Phase 6b: SLOC Validation / Data Validation
from app.api.v1.endpoints.sloc_validation import router as store_stock_router
from app.api.v1.endpoints.grid_builder import router as grid_builder_router

# Phase 7: Lookup Art Master
from app.api.v1.endpoints.lookup_art_master import router as lookup_art_master_router

# Data Checklist
from app.api.v1.endpoints.checklist import router as checklist_router

# Trends
from app.api.v1.endpoints.trends import router as trends_router

# Reports
from app.api.v1.endpoints.reports import router as reports_router

# Maintenance
from app.api.v1.endpoints.maintenance import router as maintenance_router

# Phase 6: Dashboard
from app.api.v1.endpoints.dashboard import router as dashboard_router

# Hold Dashboard — review HOLD_QTY across multiple angles
from app.api.v1.endpoints.hold_dashboard import router as hold_dashboard_router

# Pending Allocation — ARS_PEND_ALC lifecycle management
from app.api.v1.endpoints.pend_alc import router as pend_alc_router

api_router = APIRouter(prefix="/api/v1")

# Phase 1
api_router.include_router(auth_router)
api_router.include_router(users_router)
api_router.include_router(roles_router)
api_router.include_router(rls_router)
api_router.include_router(audit_router)

# Phase 2
api_router.include_router(tables_router)
api_router.include_router(data_ops_router)
api_router.include_router(upload_router)

# Phase 3
api_router.include_router(allocations_router)

# Phase 4: MSA Stock Calculation
api_router.include_router(msa_router)
api_router.include_router(msa_legacy_router)

# Phase 4b: Contribution Percentage
api_router.include_router(contrib_router)

# Phase 4c: BDC Creation
api_router.include_router(bdc_router)

# Phase 5
api_router.include_router(settings_router)

# Phase 6b: Store Stock / Data Preparation
api_router.include_router(store_stock_router)
api_router.include_router(grid_builder_router)

# Phase 7: Lookup Art Master
api_router.include_router(lookup_art_master_router)

# Phase 6
api_router.include_router(dashboard_router)
api_router.include_router(hold_dashboard_router)
api_router.include_router(pend_alc_router)

# Data Checklist
api_router.include_router(checklist_router)

# Trends
api_router.include_router(trends_router)

# Reports
api_router.include_router(reports_router)

# Listing
from app.api.v1.endpoints.listing import router as listing_router
api_router.include_router(listing_router)

# Maintenance (superadmin only)
api_router.include_router(maintenance_router)

# Pipeline (parallel MSA processing — replaces 20 machines)
from app.api.v1.endpoints.pipeline import router as pipeline_router
api_router.include_router(pipeline_router)

# Allocation Engine v2 (score-based, replaces Excel 8-level waterfall)
from app.api.v1.endpoints.allocation_engine import router as alloc_engine_router
api_router.include_router(alloc_engine_router)

# Process Docs (SOPs rendered on the Process page)
from app.api.v1.endpoints.process_docs import router as process_docs_router
api_router.include_router(process_docs_router)

# Developer Guide — auto-introspecting docs for engineers
from app.api.v1.endpoints.dev_guide import router as dev_guide_router
api_router.include_router(dev_guide_router)
